# EduAssess - 온라인 교육 평가 플랫폼

<div align="center">

![EduAssess Logo](https://img.shields.io/badge/EduAssess-교육평가시스템-blue?style=for-the-badge)

**한국어 온라인 교육 평가 시스템**

[![Windows](https://img.shields.io/badge/Windows-지원-green)](WINDOWS_SETUP.md)
[![Node.js](https://img.shields.io/badge/Node.js-18+-brightgreen)](https://nodejs.org)
[![License](https://img.shields.io/badge/License-MIT-yellow)](LICENSE)

</div>

## 🎯 주요 특징

### 🏫 교육기관 특화 설계
- **100개 과목** 지원 (국어국문학, 영어영문학, 수학 등)
- **한국형 로그인**: 학생(성명+생년월일), 교사(ID+비밀번호)
- **반응형 웹**: 모바일, 태블릿, PC 모든 기기 지원

### 📝 문제 관리 시스템
- **객관식/서술형** 문제 생성
- **이미지 업로드** 지원 (문제, 선택지)
- **실시간 편집** 및 미리보기

### 🎯 평가 시스템
- **시간 제한** 시험 
- **실시간 진행률** 표시
- **자동 저장** 기능

### 📊 채점 및 분석
- **자동 채점**: 객관식 문제
- **수동 채점**: 서술형 문제 + 피드백
- **100점 환산**: 모든 점수 표준화
- **통계 분석**: 과목별, 학생별 성과 분석

### 📄 리포트 시스템
- **PDF 성적표**: 상세한 시험 결과
- **분석 리포트**: 차트 포함 통계 자료
- **일괄 다운로드**: 여러 학생 성적 한번에

## 🚀 빠른 시작

### Windows 환경
1. **Node.js 설치**: [nodejs.org](https://nodejs.org)에서 LTS 버전
2. **프로젝트 실행**: `실행.bat` 파일 더블클릭
3. **브라우저 접속**: http://localhost:5000

### Linux/Mac 환경
```bash
npm install
npm run dev
```

## 🔐 기본 계정 정보

| 구분 | 로그인 정보 | 비고 |
|------|-------------|------|
| **교사** | admin / jhj0901 | 모든 기능 사용 가능 |
| **학생** | 성명 + 생년월일6자리 | 시험 응시만 가능 |

## 📋 시스템 요구사항

- **OS**: Windows 10+, macOS 10.15+, Ubuntu 18.04+
- **Node.js**: 18.0.0 이상
- **RAM**: 최소 4GB
- **브라우저**: Chrome, Firefox, Safari, Edge (최신 버전)

## 🎯 주요 기능

### 👨‍🏫 교사용 기능
- ✅ 문제 생성 및 관리 (객관식/서술형)
- ✅ 평가 구성 및 설정
- ✅ 실시간 채점 시스템
- ✅ 성적 분석 대시보드
- ✅ PDF 리포트 생성
- ✅ 과목별 통계 관리

### 👨‍🎓 학생용 기능
- ✅ 온라인 시험 응시
- ✅ 실시간 타이머
- ✅ 자동 저장
- ✅ 즉시 결과 확인 (객관식)

## 🛠️ 기술 스택

### Frontend
- **React 18** + TypeScript
- **Tailwind CSS** (반응형 디자인)
- **shadcn/ui** (컴포넌트 라이브러리)
- **TanStack Query** (서버 상태 관리)
- **Recharts** (차트 및 그래프)

### Backend  
- **Node.js** + Express
- **TypeScript** (타입 안전성)
- **Drizzle ORM** (데이터베이스)
- **PostgreSQL** (운영용) / 메모리DB (개발용)

### 기능 라이브러리
- **jsPDF** (PDF 생성)
- **html2canvas** (차트 캡처)
- **Multer** (파일 업로드)

## 📊 분석 및 리포트

### 통계 차트
- 📊 **점수 분포**: 구간별 학생 분포
- 🥧 **합격률**: 과목별 합격/불합격 비율  
- 📈 **과목별 비교**: 평균 점수 및 성과 분석
- 📋 **상세 테이블**: 과목별 세부 통계

### PDF 리포트
- 🎯 **개별 성적표**: 학생별 상세 결과
- 📊 **분석 리포트**: 차트 포함 통계 자료
- 📝 **과목별 리포트**: 교사용 분석 데이터

## 🔧 문제 해결

### 일반적인 문제
1. **포트 충돌**: 다른 프로그램에서 5000번 포트 사용 시
2. **npm 명령어 오류**: Node.js 재설치 필요
3. **브라우저 호환성**: 최신 브라우저 사용 권장

자세한 해결 방법은 [WINDOWS_SETUP.md](WINDOWS_SETUP.md)를 참고하세요.

## 📂 프로젝트 구조

```
eduassess-platform/
├── client/          # React 프론트엔드
├── server/          # Express 백엔드  
├── shared/          # 공통 타입 및 스키마
├── uploads/         # 업로드된 파일
├── 실행.bat         # Windows 실행 파일
└── WINDOWS_SETUP.md # 설치 가이드
```

## 🤝 기여 방법

1. Fork the Project
2. Create your Feature Branch
3. Commit your Changes  
4. Push to the Branch
5. Open a Pull Request

## 📝 라이선스

이 프로젝트는 MIT 라이선스 하에 배포됩니다. 자세한 내용은 [LICENSE](LICENSE) 파일을 참고하세요.

## 📞 지원

- 📧 **이메일**: support@eduassess.com
- 📱 **전화**: 02-1234-5678
- 💬 **카카오톡**: @eduassess

---

<div align="center">
Made with ❤️ for Korean Education System
</div>